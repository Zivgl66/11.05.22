const jwt = require('jsonwebtoken');

module.exports = (req, res, next) => {
    const token = req.query.token || req.header('x-auth-token');

    if (!token)
        return res.status(401).json({ message: 'Access denied no token provided.' });

    //No callback, no promise, how to check for failure:
    try {
        const payload = jwt.verify(token, process.env.JWT_SECRET);
        req.user = payload;
        next();
    }
    catch (e) {
        console.error(e);
        return res.status(401).json({ message: 'Invald token.' });
    }
}