const Joi = require('joi');
const mongoose = require('mongoose');
const jwt = require('jsonwebtoken');
//what to check with Mongoose, rules:
const userSchema = new mongoose.Schema({
    name: {
        type: String,
        required: true,
        minlength: 2,
        maxlength: 255
    },
    email: {
        required: true,
        minlength: 6,
        maxlength: 64,
        unique: true,
        type: String
    },
    password: {
        required: true,
        type: String,
        minlength: 6,
        maxlength: 1024 /*encrypted password takes more space*/,
    },
    createdAt: {
        type: Date,
        default: Date.now
    },
    biz: {
        required: true,
        type: Boolean
    }
});

//add methods to User schema: (not an arrow function, since this is refered)
userSchema.methods.generateToken = function () {
    const token = jwt.sign(
        { _id: this._id },
        process.env.JWT_SECRET
    );

    return token;
}

//what to check with Joi, rules:
const shcema = Joi.object({
    name: Joi.string().min(2).max(255).required(),
    email: Joi.string().min(6).max(64).email().required(),
    password: Joi.string().min(6).max(255).required(),
    biz: Joi.boolean().required(),
});

function validateUser(user) {
    return shcema.validate(user, { abortEarly: false });
}

//refernce to the collection:
const User = mongoose.model('User', userSchema);

module.exports = {
    User,
    validateUser
};