const Joi = require('joi');
const bcrypt = require('bcrypt');
const { User } = require('../models/users');
const authRouter = require('express').Router();

const authSchema = Joi.object({
    email: Joi.string().email().max(64).required(),
    password: Joi.string().min(6).max(1024).required(),
});
const validateAuth = (body) => authSchema.validate(body);
 
authRouter.post('/', async (req, res) => {
    const { error } = validateAuth(req.body);
    if (error)
        return res.json({ message: error.details.map(d => d.message) });

    //find user by email:
    const user = await User.findOne({ email: req.body.email });

    if (!user)
        return res.status(400).json({ message: `invalid email or password` });

    //validate password:
    const isValid = await bcrypt.compare(req.body.password, user.password);

    if (!isValid)
        return res.status(400).json({ message: `invalid email or password` });

    res.json({ token: user.generateToken() });
});

module.exports = authRouter;