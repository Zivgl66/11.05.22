const cardsRouter = require('express').Router();
const _ = require('lodash');
const auth = require('../middleware/auth');
const { Card, validateCard, generateBizNumber } = require('../models/cards');

cardsRouter.post('/', auth, async (req, res) => {

    const { error} = validateCard(req.body);
    if (error)
        return res.status(400).json({ message: error.details.map(d => d.message) });

    let card = new Card({
        bizNumber: await generateBizNumber(),
        user_id: req.user._id,
        ...req.body
    });

    card.bizImage = card.bizImage ?? 'https://cdn.pixabay.com/photo/2015/10/05/22/37/blank-profile-picture-973460_960_720.png'
    card = await card.save();
    res.json(card);
})

module.exports = cardsRouter;