const mongoose = require("mongoose");

const connectionOptions = {
    username: process.env.MONGO_USER || '',
    password: process.env.MONGO_PASSWORD || '',
    host: process.env.MONGO_HOST || '',
    db: process.env.MONGO_DB || '',
}

const createUri = ({ username, password, host, db }) => {
    return `mongodb+srv://${username}:${password}@${host}/${db}?retryWrites=true&w=majority`
}

const connect = (options = connectionOptions) => {
    const uri = createUri(options);
    return mongoose.connect(uri);
}

module.exports = connect;