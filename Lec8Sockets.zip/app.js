const express = require('express');
const app = express();
const server = require('http').createServer(app);

//io works on top of our http server
const io = require('socket.io')(server);

// runs when a client is connected:
io.sockets.on('connection', (client) => {
    client.on('input', (ms) => {
        io.sockets.emit('new', ms);
    })
})

app.use(express.static('public'));
app.get('/home', (req, res) => {
    res.redirect('/index.html')
});


server.listen(3000);